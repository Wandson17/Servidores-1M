<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Categorie;
use App\Models\Course;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        Categorie::create(['name'=>"Ficção"]);
        Categorie::create(['name'=>"Fantasia"]);
        Categorie::create(['name'=>"Natureza"]);
        Categorie::create(['name'=>"Biografia"]);
        Categorie::create(['name'=>"Romance"]);
        Categorie::create(['name'=>"Quadrinhos"]);
        Categorie::create(['name'=>"Aventura"]);
        Categorie::create(['name'=>"Biologia"]);
        Categorie::create(['name'=>"Matemática"]);
        Categorie::create(['name'=>"Ciência"]);
        Categorie::create(['name'=>"Geografia"]);
        Categorie::create(['name'=>"Física"]);
        Categorie::create(['name'=>"Português"]);

        Course::create(['name'=>"Eletrotécnica"]);
        Course::create(['name'=>"Informática para Internet"]);
        Course::create(['name'=>"Moda"]);
        Course::create(['name'=>"Vestuário"]);
        Course::create(['name'=>"Têxtil"]);

    }
}
