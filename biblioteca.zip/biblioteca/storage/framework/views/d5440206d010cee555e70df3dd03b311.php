

<?php $__env->startSection('main'); ?>
    <div class="row">

        <div class="col-12">

            <div class="mb-3">
                <span class="display-5 ">Livros Salvos</span>
            </div>

            <div class="table-responsive">
                <table
                    class="table table-striped
                    table-hover	
                    table-borderless
                    table-success
                    align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Título</th>
                            <th>Autor</th>
                            <th>Categoria</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <?php use App\Models\Categorie; $categories=Categorie::all(); ?>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-success">
                                <td><?php echo e($book->title); ?></td>
                                <td><?php echo e($book->author); ?></td>
                                <td><?php
                                    $categorie= Categorie::find($book->categorie_id); echo $categorie->name;                                     
                                ?></td>
                                <td>
                                    <a href="<?php echo e(url('books/edit',$book->id)); ?>" class="btn btn-outline-success">Editar</a>
                                    <a href="<?php echo e(url('books/destroy',$book->id)); ?>" class="btn btn-outline-success">Remover</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>

                    </tfoot>
                </table>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gabri\OneDrive\Documentos\Programando\PHP\Projetos\biblioteca\resources\views/dashboard.blade.php ENDPATH**/ ?>