

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="mb-4">
            <span class="h1 border-bottom ">Cadastrar nova Categoria</span>
        </div>
        <div class="col-12">

            <form action="<?php echo e(url('categories/update',$categorie->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="" class="form-label">Nome da Categoria</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($categorie->name); ?>" id=""
                        aria-describedby="helpId" placeholder="">
                </div>

                <button class="btn btn-outline-success"> Salvar </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gabri\OneDrive\Documentos\Programando\PHP\Projetos\biblioteca\resources\views/categories/edit.blade.php ENDPATH**/ ?>