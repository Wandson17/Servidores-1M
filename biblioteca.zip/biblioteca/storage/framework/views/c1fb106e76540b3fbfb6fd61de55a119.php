

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="mb-4">
            <span class="h1 border-bottom ">Cadastrar novo Livro</span>
        </div>
        <div class="col-12">

            <form action="<?php echo e(url('books')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="" class="form-label">Título do Livro</label>
                    <input type="text" class="form-control" name="title" value="<?php echo e(@old('title')); ?>" id=""
                        aria-describedby="helpId" placeholder="">
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Autor do Livro</label>
                    <input type="text" class="form-control" name="author" value="<?php echo e(@old('author')); ?>" id=""
                        aria-describedby="helpId" placeholder="">
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Número de páginas do Livro</label>
                    <input type="number" class="form-control" name="pages" value="<?php echo e(@old('author')); ?>" id=""
                        aria-describedby="helpId" placeholder="">
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Categoria</label>
                    <select class="form-select form-select-lg" name="categorie_id"  value="<?php echo e(@old('categorie_id')); ?>">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button class="btn btn-outline-success"> Salvar </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gabri\OneDrive\Documentos\Programando\PHP\Projetos\biblioteca\resources\views/books/create.blade.php ENDPATH**/ ?>