

<?php $__env->startSection('main'); ?>
<div class="row">

    <div class="col-12">

        <div class="mb-3">
            <span class="display-5 ">Categorias Salvos</span>

            <div class="mt-3 mb-3">
                <a href="<?php echo e(url('categories/create')); ?>" class="btn btn-outline-success">Nova Categoria</a>
            </div>

        </div>

        <div class="table-responsive">
            <table
                class="table table-stripeds
                table-hover	
                table-borderless
                table-success
                align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Nome</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-success">
                            <td><?php echo e($categorie->name); ?></td>
                            <td>                            
                                <a href="<?php echo e(url('categories/edit',$categorie->id)); ?>" class="btn btn-outline-success">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>

    </div>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Cliente\Desktop\biblioteca\resources\views/categories/index.blade.php ENDPATH**/ ?>