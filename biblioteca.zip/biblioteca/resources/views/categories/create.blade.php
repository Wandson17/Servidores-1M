@extends('layouts.master')

@section('main')
    <div class="row">
        <div class="mb-4">
            <span class="h1 border-bottom ">Cadastrar nova Categoria</span>
        </div>
        <div class="col-12">

            <form action="{{ url('categories') }}" method="POST">
                @csrf

                <div class="mb-3">
                    <label for="" class="form-label">Nome da Categoria</label>
                    <input type="text" class="form-control" name="name" value="{{ @old('name') }}" id=""
                        aria-describedby="helpId" placeholder="">
                </div>

                <button class="btn btn-outline-success"> Salvar </button>
            </form>
        </div>
    </div>
@endsection
