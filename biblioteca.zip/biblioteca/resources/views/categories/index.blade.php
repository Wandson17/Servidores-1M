@extends('layouts.master')

@section('main')
<div class="row">

    <div class="col-12">

        <div class="mb-3">
            <span class="display-5 ">Categorias Salvos</span>

            <div class="mt-3 mb-3">
                <a href="{{url('categories/create')}}" class="btn btn-outline-success">Nova Categoria</a>
            </div>

        </div>

        <div class="table-responsive">
            <table
                class="table table-stripeds
                table-hover	
                table-borderless
                table-success
                align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Nome</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    @foreach ($categories as $categorie)
                        <tr class="table-success">
                            <td>{{$categorie->name}}</td>
                            <td>                            
                                <a href="{{url('categories/edit',$categorie->id)}}" class="btn btn-outline-success">Editar</a>
                            </td>
                        </tr>
                    @endforeach

                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>

    </div>

</div>
    
@endsection