@extends('layouts.master')

@section('main')
    <div class="row">

        <div class="col-12">

            <div class="mb-3">
                <span class="display-5 ">Livros Salvos</span>
            </div>

            <div class="table-responsive">
                <table
                    class="table table-striped
                    table-hover	
                    table-borderless
                    table-success
                    align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Título</th>
                            <th>Autor</th>
                            <th>Categoria</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        @php use App\Models\Categorie; $categories=Categorie::all(); @endphp
                        @foreach ($books as $book)
                            <tr class="table-success">
                                <td>{{$book->title}}</td>
                                <td>{{$book->author}}</td>
                                <td>@php
                                    $categorie= Categorie::find($book->categorie_id); echo $categorie->name;                                     
                                @endphp</td>
                                <td>
                                    <a href="{{url('books/edit',$book->id)}}" class="btn btn-outline-success">Editar</a>
                                    <a href="{{url('books/destroy',$book->id)}}" class="btn btn-outline-success">Remover</a>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                    <tfoot>

                    </tfoot>
                </table>
            </div>

        </div>

    </div>
@endsection
