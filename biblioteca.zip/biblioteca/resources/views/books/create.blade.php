@extends('layouts.master')

@section('main')
    <div class="row">
        <div class="mb-4">
            <span class="h1 border-bottom ">Cadastrar novo Livro</span>
        </div>
        <div class="col-12">

            <form action="{{url('books')}}" method="POST">
                @csrf

                <div class="mb-3">
                    <label for="" class="form-label">Título do Livro</label>
                    <input type="text" class="form-control" name="title" value="{{ @old('title') }}" id=""
                        aria-describedby="helpId" placeholder="">
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Autor do Livro</label>
                    <input type="text" class="form-control" name="author" value="{{ @old('author') }}" id=""
                        aria-describedby="helpId" placeholder="">
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Número de páginas do Livro</label>
                    <input type="number" class="form-control" name="pages" value="{{ @old('author') }}" id=""
                        aria-describedby="helpId" placeholder="">
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Categoria</label>
                    <select class="form-select form-select-lg" name="categorie_id"  value="{{ @old('categorie_id') }}">
                        @foreach ($categories as $categorie)
                            <option value="{{ $categorie->id }}">{{ $categorie->name }}</option>
                        @endforeach
                    </select>
                </div>

                <button class="btn btn-outline-success"> Salvar </button>
            </form>
        </div>
    </div>
@endsection
